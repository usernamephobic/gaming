import pygame
import random

pygame.init()

# Define some colors
BLACK = (0, 0, 0)
white = (255, 255, 255)
seaweed_white = (246, 246, 246, 255)
seaweed_white2 = (242, 243, 242)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
sand_blue = (115, 132, 172)

# Set the width and height of the screen [width, height]
width = 450
height = 650
size = (450, 650)
screen = pygame.display.set_mode(size)

# --- Backgroud and text---
underwater_background = pygame.image.load("background (1).jpeg")
font = pygame.font.Font("orange juice 2.0.ttf", 100)
text = font.render("GLIDE FISH ", True, white)
textposition = ((10, 20))


# --- scores ---
font2 = pygame.font.SysFont('Verdena', 50)
score_value = 0
textposition2 = (0, 580)

def showscore(textposition2):
  score = font2.render("Score: " +str(score_value), True, white)
  screen.blit(score, (textposition2))

# --- Lives value ----

font2 = pygame.font.SysFont('Verdena', 50)
live_value = 10
textposition4 = (250, 580)

def lives(textposition4):
  live = font2.render("Lives: " +str(live_value), True, white)
  screen.blit(live, (textposition4))
  

  
# --- Sand ---
x3 = -20
y3 = 540
sand = pygame.image.load('sand(1).png')
sand.set_colorkey(sand_blue)

def sandtexture(x3, y3):
    screen.blit(sand, (x3, y3))


# ---- seaweed image and position ----
x = 427.5
y = 325
seaweed = pygame.image.load('seaweed.png')
seaweed_x = random.randrange(width)
seaweed_y = random.randrange(height)

seaweed.set_colorkey(seaweed_white)


def seaweedmoving(x, y):
    screen.blit(seaweed, (x, y))


# ---- crab image and position ----
x4 = 427.5
y4 = 325
crab_x = 450
crab_y = random.randrange(height)
crab_speed = -0.2
crab = pygame.image.load('crab.png')
crab.set_colorkey(white)


def movingcrab(x4, y4):
    screen.blit(crab, (x4, y4))

# ---- Shark image and position ----
x1 = 427.5
y1 = 325
shark_x = 100
shark_y = random.randrange(height)
shark_speed = -0.5
shark = pygame.image.load('shark.png')
shark.set_colorkey(white)


def movingshark(x1, y1):
    screen.blit(shark, (x1, y1))


# ---- AnglerFish image and position ---
anglerfish = pygame.image.load('glidefish.png')
x_coord = 50
x_speed = 0
y_coord = 300
y_speed = 0
x6 = 0
y6 = 0

def anglerfish_movement(x6, y6):
    screen.blit(anglerfish, (x6, y6))


# START SCREEN
x7 = 0
y7 = 0

# ---Menu---
  #Title for menu 
startscreen_title_font  = pygame.font.Font('startscreenfont3.ttf',100)
startscreen_title = startscreen_title_font.render('GLIDE', True, white)
startscreen_title2 = startscreen_title_font.render('FISH', True, white)
start_title_position = (85,100)
start_title_position2 = (110,200)

  #Subtitle for menu
startscreen_font = pygame.font.Font("startscreenfont2.TTF", 20)
startscreen_subtitle = startscreen_font.render("Press Space to Start", True ,white )
start_position = (55,550)
  #Background Image for start screen
startscreen = pygame.image.load('startscreen.png')
def startscreening (x7,y7):
  screen.blit(startscreen, (x7,y7))
  
menu = True
startgame = False
menuclick = False 

# --- death screen ----
deathscreen_text = startscreen_font.render("YOU DIED XDXDXDDX LOOL", True, white)
deathscreen_text_position = (300,400)
def deathscreen(x7,y7):
  screen.blit(BLACK)

deathscreening = False

done = False

# have the screen enter only start one time when you click space. make a variable called introduction = true. make a def outside the function called startgame
while not done:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_d:
                x_speed = 0.3
            if event.key == pygame.K_a:
                x_speed = -0.3
              
        if event.type == pygame.KEYUP:
          if event.key == pygame.K_d:
            x_speed = 0
          if event.key == pygame.K_a:
            x_speed = 0
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_a:
                x_speed = -0

        # Holding space Bar makes it go up
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                y_speed = - 1
                menuclick = True

        # Releasing space bar makes it go down
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_SPACE:
                y_speed = 1
                menuclick = False 

    # --- Game logic should go here
    # i.e calculations for positions, variable updates
              
    # ---- movement of shark ----
    shark_x += shark_speed
    # Shark border x axis
    if shark_x <= 0:
        shark_x = 450
        shark_y = random.randrange(height)
    # Shark border y axis
    if shark_y <= 85:
        shark_y = 85
    if shark_y >= 491:
        shark_y = 491

    # ---- movement of seaweed ----
    # Seaweed border x axis
    if seaweed_x <= 0:
        seaweed_x = 450
        seaweed_y = random.randrange(height)
        # Seaweed border for y axis
    if seaweed_y <= 85:
        seaweed_y = 85
    if seaweed_y >= 460:
        seaweed_y = 460

    # ---- movement of angler fish ----
    # movement of anglerfish
    y_coord += y_speed
    x_coord += x_speed
    if y_coord <= 85:
        y_coord = 85
    if y_coord >= 491:
        y_coord = 491

    # --- movement of crab ---
    if crab_x <=0:
        crab_x = 450
        crab_y = random.randrange(height)
    if crab_y <=95:
        crab_y = 95
    if crab_y >= 491:
        crab_y = 491
    crab_x += crab_speed


  
    if x_coord+25 > shark_x and (y_coord-25 > shark_y < y_coord+30):
      x_coord = 0
      y_coord = 300
      live_value -= 1
      #If the anglerfish touch the shark, the shark disappears 
      shark_x = 1000
      shark_y = 1000
      if shark_y >=1000:
        shark_y = 450
      if shark_x >=1000:
        shark_x = 450
        
    if x_coord+25 > crab_x and (y_coord-25>crab_y<y_coord+25):
      x_coord = 0 
      y_coord = 300
      live_value -= 1
      #If anglerfish touch the crab, the crab disappears
      crab_x = 1000
      crab_y = 1000
      if crab_y >=1000:
        crab_y = 450
      if crab_x >=1000:
        crab_x = 450
        
    if x_coord+25> seaweed_x and (y_coord-25 > seaweed_y < y_coord+25):
      score_value += 1
      #if anglerfish touch the seaweed, the crab disappears
      seaweed_x = 1000
      seaweed_y = 1000
      if seaweed_x >= 1000:
        seaweed_x =  random.randrange(width)
      if seaweed_y >= 1000:
        seaweed_y = random.randrange(height)

    # --- Drawing code should go here ----
    # Text

    # Background
    screen.blit(underwater_background, (0, 0))



    # Seaweed

    seaweedmoving(seaweed_x, seaweed_y)
      
    movingcrab(crab_x, crab_y )
    # Shark
    movingshark(shark_x, shark_y)
    # anglerfish
    anglerfish_movement(x_coord, y_coord)
    # Sand
    sandtexture(x3, y3)
    # Score and lives
    screen.blit(text,textposition)
    showscore(textposition2)
    lives(textposition4)
    if menu:
      startscreening(x7,y7)
      screen.blit(startscreen_subtitle,start_position)
      screen.blit(startscreen_title, start_title_position)
      screen.blit(startscreen_title2,start_title_position2)
      if menuclick:
        menu = False
        
    if live_value == 0:
      deathscreening = True
      deathscreen(x7,y7)
      screen.blit(BLACK)
    pygame.display.flip()

#flip and clock

# Quit the program
pygame.quit()